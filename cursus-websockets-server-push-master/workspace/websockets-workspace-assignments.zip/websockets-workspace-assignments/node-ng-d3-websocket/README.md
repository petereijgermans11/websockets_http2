Ordina J-Tech websocket course codelab

Usage:
- npm install
- node ws-server.js
- http://localhost:1337/
- Execute / Stop
- observe Raw & Canvas tabs
- JSON parameters modifyable

